import requests
import time

# ASCII Art Banner
PURPLE = '\033[95m'
BOLD = '\033[1m'
RESET = '\033[0m'

banner = f"""{PURPLE}{BOLD}
 ██████╗ ██╗████████╗██╗  ██╗██╗   ██╗██████╗     ███╗   ██╗ █████╗ ███╗   ███╗███████╗
██╔════╝ ██║╚══██╔══╝██║  ██║██║   ██║██╔══██╗    ████╗  ██║██╔══██╗████╗ ████║██╔════╝
██║  ███╗██║   ██║   ███████║██║   ██║██████╔╝    ██╔██╗ ██║███████║██╔████╔██║█████╗  
██║   ██║██║   ██║   ██╔══██║██║   ██║██╔══██╗    ██║╚██╗██║██╔══██║██║╚██╔╝██║██╔══╝  
╚██████╔╝██║   ██║   ██║  ██║╚██████╔╝██████╔╝    ██║ ╚████║██║  ██║██║ ╚═╝ ██║███████╗
 ╚═════╝ ╚═╝   ╚═╝   ╚═╝  ╚═╝ ╚═════╝ ╚═════╝     ╚═╝  ╚═══╝╚═╝  ╚═╝╚═╝     ╚═╝╚══════╝
                                                                                          
███████╗██╗███╗   ██╗██████╗ ███████╗██████╗     ██████╗ ██╗   ██╗    ██╗██████╗ ██╗███████╗
██╔════╝██║████╗  ██║██╔══██╗██╔════╝██╔══██╗    ██╔══██╗╚██╗ ██╔╝    ██║╚════██╗██║██╔════╝
█████╗  ██║██╔██╗ ██║██║  ██║█████╗  ██████╔╝    ██████╔╝ ╚████╔╝     ██║ █████╔╝██║█████╗  
██╔══╝  ██║██║╚██╗██║██║  ██║██╔══╝  ██╔══██╗    ██╔══██╗  ╚██╔╝      ██║ ╚═══██╗██║██╔══╝  
██║     ██║██║ ╚████║██████╔╝███████╗██║  ██║    ██████╔╝   ██║       ██║██████╔╝██║███████╗
╚═╝     ╚═╝╚═╝  ╚═══╝╚═════╝ ╚══════╝╚═╝  ╚═╝    ╚═════╝    ╚═╝       ╚═╝╚═════╝ ╚═╝╚══════╝
{RESET}"""

print(banner)
print()

# Replace all these usernames with the names you're looking for!
usernames = [
    "example1", "example2", "example3"
]

available = []
taken = []

print(f"Checking {len(usernames)} GitHub usernames...\n")

for i, username in enumerate(usernames, 1):
    try:
        url = f"https://github.com/{username}"
        response = requests.get(url, timeout=5)
        
        if response.status_code == 404:
            available.append(username)
            print(f"[{i}/{len(usernames)}] ✓ {username} - AVAILABLE")
        else:
            taken.append(username)
            print(f"[{i}/{len(usernames)}] ✗ {username} - taken")
        
        # Rate limiting - be respectful to GitHub
        time.sleep(0.5)
        
    except Exception as e:
        print(f"[{i}/{len(usernames)}] ? {username} - Error: {e}")
    
print("\n" + "="*50)
print(f"\nSummary:")
print(f"Available: {len(available)}")
print(f"Taken: {len(taken)}")

if available:
    print(f"\nAvailable usernames:")
    for username in available:
        print(f"  - {username}")
